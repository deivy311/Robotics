Breakdown of the operation count for a recursive algorithm to calculate Christoffel symbols numerically.

Copyright: Mohammad Safeea, May-2019
