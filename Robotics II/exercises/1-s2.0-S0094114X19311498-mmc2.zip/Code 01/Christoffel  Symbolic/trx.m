function y=trx(a)
y=eye(4);
y(1,4)=a;
end