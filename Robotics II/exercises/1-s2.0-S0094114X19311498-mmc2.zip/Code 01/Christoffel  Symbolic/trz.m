function y=trz(a)
y=eye(4);
y(3,4)=a;
end